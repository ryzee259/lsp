<?php
$koneksi = mysqli_connect('localhost', 'root', '', 'lsp');

if (!$koneksi) {
    echo "Gagal terkoneksi";
}
