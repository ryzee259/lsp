<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="../style.css" type="text/css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css">
    <title>Document</title>
</head>

<body>
    <header>
        <h3 class="logo">RESTORAN</h3>
        <nav class="nav">
            <a href="index.php">HOME</a>
            <a href="menu.php">MENU</a>
            <a href="order.php">ORDER</a>
            <a href="pelanggan.php">PELANGGAN</a>
            <a href="generate.php">GENERATE</a>
            <a href="../logout.php">logout</a>
        </nav>
    </header>
    <section class="main">
        <button class="add-btn"><a href="tambah_order.php">Tambah</a></button>
        <table>
            <tr>
                <th>NO</th>
                <th>ID</th>
                <th>ID MEJA</th>
                <th>MEJA</th>
                <th>ID MENU</th>
                <th>MENU</th>
                <th>ID PELANGGAN</th>
                <th>PELANGGAN</th>
                <th>JUMLAH</th>
                <th>ID USER</th>
                <th>OPSI</th>
            </tr>
           
<?php
include '../koneksi.php';

$query_pesanan = "SELECT id_pesanan, id_menu, id_pelanggan, jumlah, id_user FROM pesanan";
$result_pesanan = $koneksi->query($query_pesanan);

$query_menu = "SELECT id_menu, nama_menu FROM menu";
$result_menu = $koneksi->query($query_menu);

$query_pelanggan = "SELECT id_pelanggan, nama_pelanggan FROM pelanggan";
$result_pelanggan = $koneksi->query($query_pelanggan);

if (!$result_pesanan || !$result_menu || !$result_pelanggan) {
    // Jika query gagal dieksekusi, tampilkan pesan kesalahan
    echo "Error: " . $koneksi->error;
} else {
    if ($result_pesanan->num_rows > 0) {
        $no = 1;
        while ($row_pesanan = $result_pesanan->fetch_assoc()) {
            // Mencari data menu yang sesuai dengan id_menu pada pesanan
            $menu = "";
            $result_menu->data_seek(0); // Mengatur kursor kembali ke baris pertama
            while ($row_menu = $result_menu->fetch_assoc()) {
                if ($row_pesanan['id_menu'] == $row_menu['id_menu']) {
                    $menu = $row_menu['nama_menu'];
                    break;
                }
            }

            // Mencari data pelanggan yang sesuai dengan id_pelanggan pada pesanan
            $pelanggan = "";
            $result_pelanggan->data_seek(0); // Mengatur kursor kembali ke baris pertama
            while ($row_pelanggan = $result_pelanggan->fetch_assoc()) {
                if ($row_pesanan['id_pelanggan'] == $row_pelanggan['id_pelanggan']) {
                    $pelanggan = $row_pelanggan['nama_pelanggan'];
                    break;
                }
            }

            // Tampilkan data pesanan beserta data menu dan pelanggan
            echo "<tr>";
            echo "<td>" . $no++ . "</td>";
            echo "<td>" . $row_pesanan['id_pesanan'] . "</td>";
            echo "<td>" . $row_pesanan['id_menu'] . "</td>";
            echo "<td>" . $row_pesanan['id_pelanggan'] . "</td>";
            echo "<td>" . $row_pesanan['jumlah'] . "</td>";
            echo "<td>" . $menu . "</td>";
            echo "<td>" . $pelanggan . "</td>";
            echo "<td>" . $row_pesanan['id_user'] . "</td>";
            echo "</tr>";
        }
    } else {
        echo "Tidak ada data yang ditemukan.";
    }
}

?>


           